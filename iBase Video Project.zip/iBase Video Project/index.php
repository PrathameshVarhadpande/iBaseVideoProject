<!-- HTML Script -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!-- Icon -->
    <link rel="icon" href="images/iBase logo.png">

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">

    <!--Javascript-->
    <!-- <script type="text/javascript" src="js/login_form_clear_input.js"></script>
    <script src=”https://code.jquery.com/jquery-3.4.1.min.js” integrity=”sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=” crossorigin=”anonymous”></script> -->

    <!-- Font Awesome -->
    <script src="https://kit.fontawesome.com/0a44410d99.js" crossorigin="anonymous"></script>

    <title>iBase Tutorials</title>

</head>
<body>
    <div class="container-fluid">
        <img src="images/iBase logo.png">
    </div>
    <h1 class="display-6">Welcome to iBase</h1>
    <div class="container">
        <h3>Login Here</h3>
        
        <form action="index.html" method="get">
            <div class="col-md-12 mb-3">
              <input type="email" name="email" class="form-control" id="emailinput" aria-describedby="emailHelp" placeholder="Enter email" pattern="^([a-zA-Z0-9_.]{2,})+(@[a-zA-Z0-9]{2,})+(\.[a-zA-Z]{2,})?" required>
              <button class="btn-close" type="reset" id="cbtn1"></button>
            </div>
            <div class="col-md-12 mb-4">
              <input type="password" name="password" class="form-control" id="passwordinput" placeholder="Enter password" pattern="[a-zA-Z.@0-9]{8,50}" required>
              <button class="btn-close" type="reset" id="cbtn2"></button>
            </div>
            <button name="submit" type="submit" class="btn btn-primary col-12" id="lgbtn">Login</button>
        </form>            
        <a href="#" id="nreg">New Registration</a>
        <a href="#" id="fpass">Forget Password</a>
    </div>
    <?php
        if(isset($_GET['submit'])){
            $email=$_GET['email'];
            $pass=$_GET['password'];
            if($email=="admin@ibase.com" && $pass="admin12345"){
                echo "<script>alert(\"Valid User\");</script>";
            }
            else{
                echo "<script>alert(\"InValid User\");</script>";
            }
        }

    ?>
</body>
</html>