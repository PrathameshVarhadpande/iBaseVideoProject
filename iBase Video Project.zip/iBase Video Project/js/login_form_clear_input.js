$("#clearsearch1").click(function(){
    $(".resultingarticles").empty();
    $("#emailinput").val("");
  });